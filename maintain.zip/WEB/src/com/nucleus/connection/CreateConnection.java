package com.nucleus.connection;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class CreateConnection {
	Connection conn;
	Properties prop = new Properties();
	FileInputStream fis = null;

	public Connection ConnectionClass() {

		try {
//			String path = "Connection.property";
//			fis = new FileInputStream(path);
//			prop.load(fis);
			
			prop.load(this.getClass().getResourceAsStream("Connection.property"));

			String dc = prop.getProperty("DRIVERCLASS");
			String url = prop.getProperty("URL");
			String user = prop.getProperty("USERNAME");
			String pwd = prop.getProperty("PWD");

			Class.forName(dc);
			conn = DriverManager.getConnection(url, user, pwd);
		} catch (ClassNotFoundException e1) {

			e1.printStackTrace();
		} catch (SQLException e) {

			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return conn;

	}

	public void closeConnection() {
		try {
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
