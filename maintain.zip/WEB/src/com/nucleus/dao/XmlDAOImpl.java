package com.nucleus.dao;

import com.nucleus.domain.CustomerM;

public class XmlDAOImpl implements CustomerDAO{

	@Override
	public void readFromFile(String location, int Rejection) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void insertIntoDatabase(CustomerM customerM) {
		// TODO Auto-generated method stub
		
	}

	
}
