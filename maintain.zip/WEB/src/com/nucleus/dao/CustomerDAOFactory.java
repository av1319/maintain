package com.nucleus.dao;

public class CustomerDAOFactory {

	public static CustomerDAO getCustomerDAOImpl(String implType){
		
		
		
		if(implType.equals("oracle")){
			return new CustomerDAOImpl();
			
		}
		
		else if (implType.equals("xml")){
			return new XmlDAOImpl();
		}
	
	return null;
	
	}
	
}
