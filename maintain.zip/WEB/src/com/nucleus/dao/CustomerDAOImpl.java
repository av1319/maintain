package com.nucleus.dao;
import java.io.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.nucleus.connection.CreateConnection;
import com.nucleus.domain.CustomerM;
import com.nucleus.errorlog.ErrorLog;
import com.nucleus.validation.ValidationClass;

public class CustomerDAOImpl implements CustomerDAO {
	PreparedStatement preparedStatement = null;
	BufferedReader bufferedReader = null;
	ErrorLog errorLog = new ErrorLog();
	String line;
	CustomerM customerM = new CustomerM();
	StringBuffer ename;
	CreateConnection createConnection = new CreateConnection();
	Connection conn = createConnection.ConnectionClass();
	// read from file method return type list of customers
	static int count = 1;

	public void readFromFile(String loc, int rej) {

		FileReader fileReader = null;
		BufferedReader bufferedReader = null;
		ename = new StringBuffer("");
		ValidationClass validationClass = new ValidationClass();

		
		int errorCount = 0;

		try {
			fileReader = new FileReader(loc);
			bufferedReader = new BufferedReader(fileReader);
			String str1 = bufferedReader.readLine();
			
			//The SETAUTOCOMMIT method is set to false
			
			conn.setAutoCommit(false);
			while (str1 != null) {
				line = str1;
				String str[] = str1.split("~", -1);

				// Validation CustomerCode
				if (validationClass.nullCheck(str[0]) && (str[0].length()<=10) ){
					customerM.setCustomerCode(str[0]);

				} else {

					errorCount++;
					System.out.println("Customer Code Validation False  "+str[0]);
					ename.append("Customer Code invalid------> ");
					
				}

				// Validation CustomrName
				int len = str[1].length();
				if (validationClass.customerNameValidation(str[1])
						&& (len <= 30)) {

					customerM.setCustomerName(str[1]);
				} else {

					errorCount++;
					System.out.println("Customer Name Validation False  "+str[1]);
					ename.append("Customer Name Invalid------> ");
				}

				// Validation CustomerAddress 1
				len = str[2].length();
				if (validationClass.nullCheck(str[2]) && (len <= 100)) {
					customerM.setCustomerAdd1(str[2]);

				} else {

					errorCount++;
					System.out.println("Customer address1 Validation False "+str[2]);
					ename.append("Customer Addr 1 Invalid------> ");
					
				}

				// Validation CustomerAddress 2
				if (str[3].length() <= 100) {

					customerM.setCustomerAdd2(str[3]);
				} else {

					errorCount++;
					System.out.println("Customer address2 Validation False  "+str[3]);
					ename.append("Customer Addr 2 Invalid------> ");
					
				}

				// Validation CustomerPinCode
				len = str[4].length();
				if (validationClass.fieldLengthValidation((Long
						.parseLong(str[4]))) && len <= 6) {

					customerM.setCustomerPinCode(Long.parseLong(str[4]));
				} else {

					errorCount++;
					System.out.println("Customer Pincode Validation False  "+str[4]);
					ename.append("Customer PinCode Invalid------> ");
					
				}

				// Validation CustomerEmail Address
				len = str[5].length();
				if (validationClass.emailValidation(str[5]) && (len <= 100)) {

					customerM.setEmailAdd(str[5]);
				} else {

					errorCount++;
					System.out.println("Customer Email address Validation False  "+str[5]);
					ename.append("Customer Email Invalid------> ");
					
				}

				// Validation Customer Contact Number
				if (str[6].length() <= 20) {

					customerM.setContact_Number(Long.parseLong(str[6]));
				} else {

					errorCount++;
					System.out.println("Customer Contact No. Validation False  "+str[6]);
					ename.append("Customer Phone No. Invalid------> ");
					
				}

				// Validation PrimaryContactPerson
				len = str[7].length();
				if (validationClass.nullCheck(str[7]) && (len <= 100)) {
					customerM.setPrimaryContactPerson(str[7]);

				} else {

					errorCount++;
					System.out.println("Customer Primary contact person Validation False  "+str[7]);
					ename.append("Customer Primary Contact Person Invalid ------>");
					
				}

				// Validation Record Status
				len = str[8].length();
				if (validationClass.recordStatusValidation(str[8])
						&& (len <= 1)) {

					customerM.setRecordStatus(str[8]);
				} else {

					errorCount++;
					System.out.println("Customer record status Validation False  "+str[8]);
					ename.append("Customer Record Status Invalid------> ");
					
				}
				// ////////////////////////////////////////////////////
				// Validation Flag
				len = str[9].length();
				if (validationClass.flagValidation(str[9]) && (len <= 1)) {

					customerM.setFlag(str[9]);
				} else {

					errorCount++;
					System.out.println("Customer flag Validation False  "+str[9]);
					ename.append("Customer FLAG ACTIVE/INACTIVE Invalid------> ");
					
				}

				// Validation Create Date
				if (validationClass.nullCheck(str[10])) {
					customerM.setCreateDate(str[10]);

				} else {

					errorCount++;
					System.out.println("create date Validation False  "+str[10]);
					ename.append("Create Date length is less than specified------>");
				}

				// Validation Create BY
				len = str[11].length();
				if (validationClass.nullCheck(str[11]) && (len <= 30)) {
					customerM.setCreatedBy(str[11]);

				} else {

					errorCount++;
					System.out.println("Created By Validation False  "+str[11]);
					ename.append("Record Created By Field Invalid------> ");
					
				}
				// *********************************
				customerM.setModifiedDate(str[12]);
				// -*******************************

				// Validation Modified BY
				len = str[13].length();
				if (len <= 30) {

					customerM.setModifiedBy(str[13]);
				} else {

					errorCount++;
					System.out.println("modified by Validation False  "+str[13]);
					ename.append("Record Modified by  field Invalid ------->");
					
				}
				// *****************************************
				customerM.setAuthorisedDate(str[14]);
				// **************************************************

				// Validation Authorised BY
				len = str[15].length();
				if (str[15].length() <= 30) {

					customerM.setAuthorisedBy(str[15]);
				} else {

					errorCount++;
					System.out.println("AUthorised by Validation False  "+str[15]);
					ename.append("Customer record authorised  by field -------> ");
					
				}

				// Check for Rejection Level Inputs

				if (errorCount == 0)//When no error is detected 
				{
					insertIntoDatabase(customerM);
					str1 = bufferedReader.readLine();

				}
				// when Atleast one validation is false
				else {
					if (rej == 1) // When User has selected Record Level Rejection
					{

						errorLog.saveToFile(ename+str1);
						ename=new StringBuffer();
						str1 = bufferedReader.readLine();
						errorCount = 0;
					} else {
						System.out.println("Error Found ");
						errorLog.saveError(ename+str1);// error log
						ename=new StringBuffer();
						errorLog.copyfile(loc);// copies file into another file
						conn.rollback();
						System.exit(0);

					}

				}
			}
				conn.commit();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		} catch (Exception e) {

			e.printStackTrace();
		}

		finally {

			try {
                createConnection.closeConnection();
				bufferedReader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}

		}
	}

	public void insertIntoDatabase(CustomerM customerM) {
		// Function to insert data in database

		try {

			preparedStatement = conn.prepareStatement("insert into seq1234 values(mysequence121.nextval,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
			preparedStatement.setString(1, customerM.getCustomerCode());
			preparedStatement.setString(2, customerM.getCustomerName());
			preparedStatement.setString(3, customerM.getCustomerAdd1());
			preparedStatement.setString(4, customerM.getCustomerAdd2());
			preparedStatement.setLong(5, customerM.getCustomerPinCode());
			preparedStatement.setString(6, customerM.getEmailAdd());
			preparedStatement.setLong(7, customerM.getContact_Number());
			preparedStatement.setString(8, customerM.getPrimaryContactPerson());
			preparedStatement.setString(9, customerM.getRecordStatus());
			preparedStatement.setString(10, customerM.getFlag());
			preparedStatement.setString(11, customerM.getCreateDate());
			preparedStatement.setString(12, customerM.getCreatedBy());
			preparedStatement.setString(13, customerM.getModifiedDate());
			preparedStatement.setString(14, customerM.getModifiedBy());
			preparedStatement.setString(15, customerM.getAuthorisedDate());
			preparedStatement.setString(16, customerM.getAuthorisedBy());
			preparedStatement.executeUpdate();

			System.out.print("line" + count++);
			System.out.print(" Saved\n");

		} catch (SQLException e) {
			
			
			errorLog.saveToFile(" unique key----> "+line);
		
		}

	}

}
