package com.nucleus.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.nucleus.dao.CustomerDAO;
import com.nucleus.dao.CustomerDAOFactory;
import com.nucleus.dao.CustomerDAOImpl;
import com.nucleus.domain.CustomerM;

/**
 * Servlet implementation class Upload
 */
@WebServlet("/Upload")
public class Upload extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Upload() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		CustomerM customerM = new CustomerM();
		CustomerDAO c = CustomerDAOFactory.getCustomerDAOImpl("oracle");
		
		response.setContentType("text/html");
		PrintWriter p=response.getWriter();
		String path=request.getParameter("fileName");
		Integer rejection=Integer.parseInt(request.getParameter("rejection"));
		
		if(path.endsWith(".txt"))
		{
			c.readFromFile(path,rejection);	
		}
		else {
			System.out.println("INVALID FILE FORMAT");
		}
		
		
		
		
	}

}
